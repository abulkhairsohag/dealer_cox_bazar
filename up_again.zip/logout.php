<?php 
include_once("class/Session.php");
Session::init();
Session::destroy();
 ?>