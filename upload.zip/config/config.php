<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "abulkhair45");
define("DB_NAME", "dealer_cox_bazar");

date_default_timezone_set('Asia/Dhaka');


?>